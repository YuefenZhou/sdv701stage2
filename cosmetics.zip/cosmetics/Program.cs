﻿using System;
using System.Windows.Forms;
// Name : winona
// Date modified: 21/6/2019 
namespace cosmetics
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
//            Application.Run(new frmMain());
            Application.Run(new frmMain());
        }
    }
}
