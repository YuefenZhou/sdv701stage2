﻿// Name : winona
// Date modified: 21/6/2019 
namespace cosmetics
{
    public sealed partial class frmDry : cosmetics.frmDetails
    {
        private static readonly frmDry Instance = new frmDry();
        private frmDry()
        {
            InitializeComponent();
        }
        public static void Run(clsCosmetic prDry)
        {
             Instance.SetDetails(prDry);
        }
        protected override void updateForm()
        {
            base.updateForm();
            cmbLevel.Text = _Cosmetic.moisturizer;
            cmbOxi.Text = _Cosmetic.Oxidizability;
        }

        protected override void pushData()
        {
            base.pushData();
            _Cosmetic.moisturizer = cmbLevel.Text;
            _Cosmetic.Oxidizability = cmbOxi.Text;
        }
    }
}
