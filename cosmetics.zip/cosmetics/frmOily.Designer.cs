﻿namespace cosmetics
{
    partial class frmOily
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOily = new System.Windows.Forms.Label();
            this.cmbLevel = new System.Windows.Forms.ComboBox();
            this.lblLevel = new System.Windows.Forms.Label();
            this.lblOilcontrol = new System.Windows.Forms.Label();
            this.cmbOilcontrol = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblOily
            // 
            this.lblOily.AutoSize = true;
            this.lblOily.Location = new System.Drawing.Point(88, 73);
            this.lblOily.Name = "lblOily";
            this.lblOily.Size = new System.Drawing.Size(34, 20);
            this.lblOily.TabIndex = 18;
            this.lblOily.Text = "Oily";
            // 
            // cmbLevel
            // 
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.Items.AddRange(new object[] {
            "Low",
            "Meduim",
            "High"});
            this.cmbLevel.Location = new System.Drawing.Point(123, 191);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(121, 28);
            this.cmbLevel.TabIndex = 17;
            this.cmbLevel.Text = "Medium";
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Location = new System.Drawing.Point(22, 194);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(95, 20);
            this.lblLevel.TabIndex = 16;
            this.lblLevel.Text = "Cover Level:";
            // 
            // lblOilcontrol
            // 
            this.lblOilcontrol.AutoSize = true;
            this.lblOilcontrol.Location = new System.Drawing.Point(290, 194);
            this.lblOilcontrol.Name = "lblOilcontrol";
            this.lblOilcontrol.Size = new System.Drawing.Size(86, 20);
            this.lblOilcontrol.TabIndex = 19;
            this.lblOilcontrol.Text = "Oil Control:";
            // 
            // cmbOilcontrol
            // 
            this.cmbOilcontrol.FormattingEnabled = true;
            this.cmbOilcontrol.Items.AddRange(new object[] {
            "Low",
            "Medium",
            "High"});
            this.cmbOilcontrol.Location = new System.Drawing.Point(382, 191);
            this.cmbOilcontrol.Name = "cmbOilcontrol";
            this.cmbOilcontrol.Size = new System.Drawing.Size(121, 28);
            this.cmbOilcontrol.TabIndex = 20;
            this.cmbOilcontrol.Text = "Medium";
            // 
            // frmOily
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(528, 346);
            this.Controls.Add(this.cmbOilcontrol);
            this.Controls.Add(this.lblOilcontrol);
            this.Controls.Add(this.lblOily);
            this.Controls.Add(this.cmbLevel);
            this.Controls.Add(this.lblLevel);
            this.Name = "frmOily";
            this.Text = "Oily";
            this.Controls.SetChildIndex(this.lblLevel, 0);
            this.Controls.SetChildIndex(this.cmbLevel, 0);
            this.Controls.SetChildIndex(this.lblOily, 0);
            this.Controls.SetChildIndex(this.lblOilcontrol, 0);
            this.Controls.SetChildIndex(this.cmbOilcontrol, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOily;
        private System.Windows.Forms.ComboBox cmbLevel;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.Label lblOilcontrol;
        private System.Windows.Forms.ComboBox cmbOilcontrol;
    }
}
