﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
// Name : winona
// Date modified: 21/6/2019 
namespace cosmetics
{
    public partial class frmCosmetics : Form
    {
        private clsCategory _Category;

        private static Dictionary<String, frmCosmetics> _CosmeticsFormList =
            new Dictionary<String, frmCosmetics>();
        public frmCosmetics()
        {
            InitializeComponent();
        }

        public static void Run(clsCategory prCategory)
        {
            frmCosmetics lcCosmeticForm;
            if (string.IsNullOrEmpty(prCategory.Name) ||
            !_CosmeticsFormList.TryGetValue(prCategory.Name, out lcCosmeticForm))
            {
                lcCosmeticForm = new frmCosmetics();
                _CosmeticsFormList.Add(prCategory.Name, lcCosmeticForm);
                lcCosmeticForm.SetDetails(prCategory);
            }
            else
            {
                lcCosmeticForm.Show();
                lcCosmeticForm.Activate();
            }
        }

        private async void UpdateDisplay()
        {
            lbCosmetics.DataSource = null;
            lbCosmetics.DataSource = await ServiceClient.GetCategoryCosmeticsAsync(_Category.Name);
        }

        public void SetDetails(clsCategory prCategory)
        {
            _Category = prCategory;
            lblCatergory.Text = "Category: " + _Category.Name;
            txtDescription.Enabled = string.IsNullOrEmpty(_Category.Name);
            txtDescription.Text = _Category.Description;
            Show();
            UpdateDisplay();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void LbCosmetics_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                frmDetails.DispatchCosmeticForm(lbCosmetics.SelectedValue as clsCosmetic);
                UpdateDisplay();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void BtnDelete_Click(object sender, EventArgs e)
        {
            int lcIndex = lbCosmetics.SelectedIndex;

            if (lcIndex >= 0 && MessageBox.Show("Are you sure?", "Deleting Cosmetic", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show(await ServiceClient.DeleteCosmeticAsync(lbCosmetics.SelectedItem as clsCosmetic));
                UpdateDisplay();
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string lcReply = cmbSkintype.Text;
            if (!string.IsNullOrEmpty(lcReply)) // not cancelled?
            {
                clsCosmetic lcCosmetic = clsCosmetic.NewCosmetic(lcReply);
                lcCosmetic.Category = _Category.Name;
                if (lcCosmetic != null) // valid cosmetic created?
                {
                    frmDetails.DispatchCosmeticForm(lcCosmetic);
                    if (!string.IsNullOrEmpty(lcCosmetic.Name)) // not cancelled?
                    {
                        UpdateDisplay();
                    }
                }
            }
        }
    }
}
