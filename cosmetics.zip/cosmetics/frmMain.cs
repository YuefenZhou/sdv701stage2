﻿using System;
using System.Windows.Forms;

// Name : winona
// Date modified: 21/6/2019 
namespace cosmetics
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        public async void UpdateDisplay()
        {
            lbCategory.DataSource = null;
            lbCategory.DataSource = await ServiceClient.GetCategoryNamesAsync();
            lbCosmeticOrders.DataSource = null;
            lbCosmeticOrders.DataSource = await ServiceClient.GetAllOrdersAsync();
            decimal lcTotal = 0;
            foreach (clsOrder Item in lbCosmeticOrders.Items)
            {
                lcTotal = lcTotal + Item.cost;
            }
            lblTotal.Text = "Total: $" + lcTotal.ToString();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            UpdateDisplay();
        }

        private void BtnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void LbCosmeticOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            clsOrder lcOrder = (clsOrder)lbCosmeticOrders.SelectedItem;
            if (lcOrder == null)
                lblInformation.Text = "";
            else
                lblInformation.Text = "Information:" +
                    "\nOrder #: " + lcOrder.Id.ToString() +
                    "\nWho Buy: " + lcOrder.name +
                    "\nEmail: " + lcOrder.email +
                    "\nItem: " + lcOrder.item +
                    "\nDate Sold: " + lcOrder.date +
                    "\nTotal $: " + lcOrder.cost.ToString();
        }

        private void LbCategory_DoubleClick(object sender, EventArgs e)
        {
            clsCategory lcKey;

            lcKey = (clsCategory)lbCategory.SelectedItem;
            if (lcKey.Name != null)
                try
                {
                    frmCosmetics.Run((clsCategory)lbCategory.SelectedItem);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "This should never occur");
                }
        }

        private async void BtnDeleteOrder_Click(object sender, EventArgs e)
        {
            int lcIndex = lbCosmeticOrders.SelectedIndex;

            if (lcIndex >= 0 && MessageBox.Show("Are you sure?", "Deleting Cosmetic", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                clsOrder lcOrder = lbCosmeticOrders.SelectedItem as clsOrder;
                MessageBox.Show(await ServiceClient.DeleteOrderAsync(lcOrder.Id.ToString()));
                UpdateDisplay();
            }
        }
    }
}
