﻿namespace cosmetics
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbProducts = new System.Windows.Forms.GroupBox();
            this.lblCategory2 = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lbCategory = new System.Windows.Forms.ListBox();
            this.btnQuit = new System.Windows.Forms.Button();
            this.gbOrders = new System.Windows.Forms.GroupBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.lblInformation = new System.Windows.Forms.Label();
            this.lbCosmeticOrders = new System.Windows.Forms.ListBox();
            this.gbProducts.SuspendLayout();
            this.gbOrders.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbProducts
            // 
            this.gbProducts.Controls.Add(this.lblCategory2);
            this.gbProducts.Controls.Add(this.lblCategory);
            this.gbProducts.Controls.Add(this.lbCategory);
            this.gbProducts.Location = new System.Drawing.Point(461, 13);
            this.gbProducts.Name = "gbProducts";
            this.gbProducts.Size = new System.Drawing.Size(397, 394);
            this.gbProducts.TabIndex = 1;
            this.gbProducts.TabStop = false;
            this.gbProducts.Text = "Product Management";
            // 
            // lblCategory2
            // 
            this.lblCategory2.AutoSize = true;
            this.lblCategory2.Location = new System.Drawing.Point(69, 355);
            this.lblCategory2.Name = "lblCategory2";
            this.lblCategory2.Size = new System.Drawing.Size(272, 20);
            this.lblCategory2.TabIndex = 2;
            this.lblCategory2.Text = "Double Click Catergory To Manage It!";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblCategory.Location = new System.Drawing.Point(13, 36);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(106, 21);
            this.lblCategory.TabIndex = 1;
            this.lblCategory.Text = "Category";
            // 
            // lbCategory
            // 
            this.lbCategory.FormattingEnabled = true;
            this.lbCategory.ItemHeight = 20;
            this.lbCategory.Location = new System.Drawing.Point(17, 60);
            this.lbCategory.Name = "lbCategory";
            this.lbCategory.Size = new System.Drawing.Size(359, 284);
            this.lbCategory.TabIndex = 0;
            this.lbCategory.DoubleClick += new System.EventHandler(this.LbCategory_DoubleClick);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(461, 418);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(397, 53);
            this.btnQuit.TabIndex = 2;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // gbOrders
            // 
            this.gbOrders.Controls.Add(this.lblTotal);
            this.gbOrders.Controls.Add(this.btnDeleteOrder);
            this.gbOrders.Controls.Add(this.lblInformation);
            this.gbOrders.Controls.Add(this.lbCosmeticOrders);
            this.gbOrders.Location = new System.Drawing.Point(12, 13);
            this.gbOrders.Name = "gbOrders";
            this.gbOrders.Size = new System.Drawing.Size(428, 475);
            this.gbOrders.TabIndex = 3;
            this.gbOrders.TabStop = false;
            this.gbOrders.Text = "Cosmetic Orders";
            // 
            // lblTotal
            // 
            this.lblTotal.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblTotal.Location = new System.Drawing.Point(29, 36);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(379, 21);
            this.lblTotal.TabIndex = 4;
            this.lblTotal.Text = "Total: $0";
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.Location = new System.Drawing.Point(17, 405);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(391, 53);
            this.btnDeleteOrder.TabIndex = 3;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = true;
            this.btnDeleteOrder.Click += new System.EventHandler(this.BtnDeleteOrder_Click);
            // 
            // lblInformation
            // 
            this.lblInformation.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblInformation.Location = new System.Drawing.Point(23, 207);
            this.lblInformation.Name = "lblInformation";
            this.lblInformation.Size = new System.Drawing.Size(385, 200);
            this.lblInformation.TabIndex = 1;
            this.lblInformation.Text = "Information!";
            // 
            // lbCosmeticOrders
            // 
            this.lbCosmeticOrders.FormattingEnabled = true;
            this.lbCosmeticOrders.ItemHeight = 20;
            this.lbCosmeticOrders.Location = new System.Drawing.Point(17, 60);
            this.lbCosmeticOrders.Name = "lbCosmeticOrders";
            this.lbCosmeticOrders.Size = new System.Drawing.Size(391, 144);
            this.lbCosmeticOrders.TabIndex = 0;
            this.lbCosmeticOrders.SelectedIndexChanged += new System.EventHandler(this.LbCosmeticOrders_SelectedIndexChanged);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 500);
            this.Controls.Add(this.gbOrders);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.gbProducts);
            this.Name = "frmMain";
            this.Text = "Cosmetic Store";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.gbProducts.ResumeLayout(false);
            this.gbProducts.PerformLayout();
            this.gbOrders.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbProducts;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ListBox lbCategory;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.GroupBox gbOrders;
        private System.Windows.Forms.Label lblInformation;
        private System.Windows.Forms.ListBox lbCosmeticOrders;
        private System.Windows.Forms.Label lblCategory2;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnDeleteOrder;
    }
}

