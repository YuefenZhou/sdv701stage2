﻿// Name : winona
// Date modified: 21/6/2019 
// Class description:Create and define class clsCosmetic
namespace cosmetics
{
    public class clsCosmetic
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
        public string Category { get; set; }
        public string Skintype { get; set; }
        public string Cover { get; set; }
        public string moisturizer { get; set; }
        public string OilyControl { get; set; }
        public string Oxidizability { get; set; }

        public override string ToString()
        {
            return Name;
        }

        internal static clsCosmetic NewCosmetic(string prType)
        {
            return new clsCosmetic() { Skintype = prType };
        }
    }
}
