﻿// Name : winona
// Date modified: 21/6/2019 
namespace cosmetics
{
    public sealed partial class frmOily : cosmetics.frmDetails
    {
        public static readonly frmOily Instance = new frmOily();
        private frmOily()
        {
            InitializeComponent();
        }
        public static void Run(clsCosmetic prOily)
        {
            Instance.SetDetails(prOily);
        }
        protected override void updateForm()
        {
            base.updateForm();
            //txtCover.Text = _Cosmetic.Cover;
            //txtOilControl.Text = _Cosmetic.OilyControl;
        }
        protected override void pushData()
        {
            base.pushData();
            //_Cosmetic.Cover = txtCover.Text;
            //_Cosmetic.OilyControl = txtOilControl.Text;
        }

    }
}
