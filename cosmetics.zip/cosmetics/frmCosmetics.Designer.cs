﻿namespace cosmetics
{
    partial class frmCosmetics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCatergory = new System.Windows.Forms.Label();
            this.lbCosmetics = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.cmbSkintype = new System.Windows.Forms.ComboBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblCatergory
            // 
            this.lblCatergory.AutoSize = true;
            this.lblCatergory.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblCatergory.Location = new System.Drawing.Point(18, 17);
            this.lblCatergory.Name = "lblCatergory";
            this.lblCatergory.Size = new System.Drawing.Size(262, 21);
            this.lblCatergory.TabIndex = 0;
            this.lblCatergory.Text = "Catergory: Foundation";
            // 
            // lbCosmetics
            // 
            this.lbCosmetics.FormattingEnabled = true;
            this.lbCosmetics.ItemHeight = 20;
            this.lbCosmetics.Location = new System.Drawing.Point(579, 53);
            this.lbCosmetics.Name = "lbCosmetics";
            this.lbCosmetics.Size = new System.Drawing.Size(418, 244);
            this.lbCosmetics.TabIndex = 1;
            this.lbCosmetics.DoubleClick += new System.EventHandler(this.LbCosmetics_DoubleClick);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(444, 88);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(124, 54);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add New";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(445, 164);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(124, 53);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // btnclose
            // 
            this.btnclose.Location = new System.Drawing.Point(445, 242);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(124, 53);
            this.btnclose.TabIndex = 4;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cmbSkintype
            // 
            this.cmbSkintype.FormattingEnabled = true;
            this.cmbSkintype.Items.AddRange(new object[] {
            "dry",
            "oily"});
            this.cmbSkintype.Location = new System.Drawing.Point(445, 52);
            this.cmbSkintype.Name = "cmbSkintype";
            this.cmbSkintype.Size = new System.Drawing.Size(123, 28);
            this.cmbSkintype.TabIndex = 6;
            this.cmbSkintype.Text = "dry";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(13, 52);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(408, 243);
            this.txtDescription.TabIndex = 7;
            // 
            // frmCosmetics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 317);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.cmbSkintype);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lbCosmetics);
            this.Controls.Add(this.lblCatergory);
            this.Name = "frmCosmetics";
            this.Text = "Cosmetics";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCatergory;
        private System.Windows.Forms.ListBox lbCosmetics;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.ComboBox cmbSkintype;
        private System.Windows.Forms.TextBox txtDescription;
    }
}