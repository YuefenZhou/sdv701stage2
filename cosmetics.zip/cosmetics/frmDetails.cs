﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
// Name : winona
// Date modified: 21/6/2019 
namespace cosmetics
{
    public partial class frmDetails : Form
    {
        protected clsCosmetic _Cosmetic;

        public frmDetails()
        {
            InitializeComponent();
        }

        public void SetDetails(clsCosmetic prCosmetic)
        {
            _Cosmetic = prCosmetic;
            updateForm();
            ShowDialog();
        }

        private async void BtnOk_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                pushData();
                if (txtItem.Enabled)
                    MessageBox.Show(await ServiceClient.InsertCosmeticAsync(_Cosmetic));
                else
                    MessageBox.Show(await ServiceClient.UpdateCosmeticAsync(_Cosmetic));

                Close();
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        protected virtual bool isValid()
        {
            return true;
        }

        protected virtual void updateForm()
        {
            txtItem.Text = _Cosmetic.Name;
            txtCost.Text = _Cosmetic.Price.ToString();
            txtStock.Text = _Cosmetic.Stock.ToString();
            txtItem.Enabled = string.IsNullOrEmpty(_Cosmetic.Name);
        }

        protected virtual void pushData()
        {
            _Cosmetic.Name = txtItem.Text;
            _Cosmetic.Price = decimal.Parse(txtCost.Text);
            _Cosmetic.Stock = int.Parse(txtStock.Text);
        }

        public delegate void LoadWorkFormDelegate(clsCosmetic prCosmetic);

        public static Dictionary<string, Delegate> _CosmeticsForm = new Dictionary<string, Delegate>
        {
          {"dry", new LoadWorkFormDelegate(frmDry.Run)},
          {"oily", new LoadWorkFormDelegate(frmOily.Run)},
        };


        public static void DispatchCosmeticForm(clsCosmetic prCosmetic)
        {
            _CosmeticsForm[prCosmetic.Skintype].DynamicInvoke(prCosmetic);
        }
    }
}
