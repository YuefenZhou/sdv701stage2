﻿namespace cosmetics
{
    partial class frmDry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLevel = new System.Windows.Forms.Label();
            this.cmbLevel = new System.Windows.Forms.ComboBox();
            this.lblDry = new System.Windows.Forms.Label();
            this.cmbOxi = new System.Windows.Forms.ComboBox();
            this.lblOxi = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Location = new System.Drawing.Point(26, 189);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(131, 20);
            this.lblLevel.TabIndex = 13;
            this.lblLevel.Text = "Moisturizer Level:";
            // 
            // cmbLevel
            // 
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.Items.AddRange(new object[] {
            "Low",
            "Medium",
            "High"});
            this.cmbLevel.Location = new System.Drawing.Point(163, 188);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(340, 28);
            this.cmbLevel.TabIndex = 14;
            this.cmbLevel.Text = "High";
            // 
            // lblDry
            // 
            this.lblDry.AutoSize = true;
            this.lblDry.Location = new System.Drawing.Point(87, 67);
            this.lblDry.Name = "lblDry";
            this.lblDry.Size = new System.Drawing.Size(33, 20);
            this.lblDry.TabIndex = 15;
            this.lblDry.Text = "Dry";
            // 
            // cmbOxi
            // 
            this.cmbOxi.FormattingEnabled = true;
            this.cmbOxi.Items.AddRange(new object[] {
            "Low",
            "Medium",
            "High"});
            this.cmbOxi.Location = new System.Drawing.Point(163, 233);
            this.cmbOxi.Name = "cmbOxi";
            this.cmbOxi.Size = new System.Drawing.Size(340, 28);
            this.cmbOxi.TabIndex = 17;
            this.cmbOxi.Text = "High";
            // 
            // lblOxi
            // 
            this.lblOxi.AutoSize = true;
            this.lblOxi.Location = new System.Drawing.Point(26, 234);
            this.lblOxi.Name = "lblOxi";
            this.lblOxi.Size = new System.Drawing.Size(94, 20);
            this.lblOxi.TabIndex = 16;
            this.lblOxi.Text = "Oxidizability:";
            // 
            // frmDry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(528, 348);
            this.Controls.Add(this.cmbOxi);
            this.Controls.Add(this.lblOxi);
            this.Controls.Add(this.lblDry);
            this.Controls.Add(this.cmbLevel);
            this.Controls.Add(this.lblLevel);
            this.Name = "frmDry";
            this.Text = "Dry";
            this.Controls.SetChildIndex(this.lblLevel, 0);
            this.Controls.SetChildIndex(this.cmbLevel, 0);
            this.Controls.SetChildIndex(this.lblDry, 0);
            this.Controls.SetChildIndex(this.lblOxi, 0);
            this.Controls.SetChildIndex(this.cmbOxi, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.ComboBox cmbLevel;
        private System.Windows.Forms.Label lblDry;
        private System.Windows.Forms.ComboBox cmbOxi;
        private System.Windows.Forms.Label lblOxi;
    }
}
