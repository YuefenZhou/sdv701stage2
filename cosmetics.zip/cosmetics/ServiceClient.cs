﻿using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

// Name : winona
// Date modified: 21/6/2019 
// Description:Used to generate server requests
namespace cosmetics
{
    public static class ServiceClient
    {
        internal async static Task<List<clsCategory>> GetCategoryNamesAsync()
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsCategory>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/cosmetic/GetCategoryNames/"));
        }

        internal async static Task<List<clsOrder>> GetAllOrdersAsync()
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsOrder>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/cosmetic/GetAllOrders/"));
        }

        internal async static Task<List<clsCosmetic>> GetCategoryCosmeticsAsync(string prName)
        {
            using (HttpClient lcHttpClient = new HttpClient())
                return JsonConvert.DeserializeObject<List<clsCosmetic>>
            (await lcHttpClient.GetStringAsync("http://localhost:60064/api/cosmetic/GetCategoryCosmetics?Name=" + prName));
        }

        internal async static Task<string> UpdateCosmeticAsync(clsCosmetic prCosmetic)
        {
            return await InsertOrUpdateAsync(prCosmetic, "http://localhost:60064/api/cosmetic/PutCosmetic", "PUT");
        }

        internal async static Task<string> InsertCosmeticAsync(clsCosmetic prCosmetic)
        {
            return await InsertOrUpdateAsync(prCosmetic, "http://localhost:60064/api/cosmetic/PostCosmetic", "POST");
        }

        private async static Task<string> InsertOrUpdateAsync<TItem>(TItem prItem, string prUrl, string prRequest)
        {
            using (HttpRequestMessage lcReqMessage = new HttpRequestMessage(new HttpMethod(prRequest), prUrl))
            using (lcReqMessage.Content =
        new StringContent(JsonConvert.SerializeObject(prItem), Encoding.Default, "application/json"))
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.SendAsync(lcReqMessage);
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
        }

        internal async static Task<string> DeleteCosmeticAsync(clsCosmetic prCosmetic)
        {
            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.DeleteAsync
                ($"http://localhost:60064/api/cosmetic/DeleteCosmetic?Name={prCosmetic.Name}");
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
        }

        internal async static Task<string> DeleteOrderAsync(string Id)
        {

            using (HttpClient lcHttpClient = new HttpClient())
            {
                HttpResponseMessage lcRespMessage = await lcHttpClient.DeleteAsync
                ($"http://localhost:60064/api/cosmetic//DeleteOrder?Id={Id}");
                return await lcRespMessage.Content.ReadAsStringAsync();
            }
        }
    }
}
