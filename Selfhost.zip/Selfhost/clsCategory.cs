﻿// Name : winona
// Date modified: 21/6/2019 
// Class description:Create and define class clsCategory
namespace Selfhost
{
    public class clsCategory
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
