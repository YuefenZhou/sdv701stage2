﻿using System;
using System.Collections.Generic;
using System.Data;
// Name : winona
// Date modified: 21/6/2019 
// Description:Control functions for creating, reading, adding, updating, deleting and other functions
namespace Selfhost
{
    public class CosmeticController : System.Web.Http.ApiController
    {
        public List<clsCategory> GetCategoryNames()
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM category", null);
            List<clsCategory> lcNames = new List<clsCategory>();
            foreach (DataRow dr in lcResult.Rows)
                lcNames.Add(dataRow2clsCategory(dr));
            return lcNames;
        }

        private clsCategory dataRow2clsCategory(DataRow prDataRow)
        {
            return new clsCategory()
            {
                Description= Convert.ToString(prDataRow["description"]),
                Name = Convert.ToString(prDataRow["name"]),
            };
        }

        public List<clsOrder> GetAllOrders()
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM orders", null);
            List<clsOrder> lcNames = new List<clsOrder>();
            foreach (DataRow dr in lcResult.Rows)
                lcNames.Add(dataRow2clsOrder(dr));
            return lcNames;
        }

        private clsOrder dataRow2clsOrder(DataRow prDataRow)
        {
            return new clsOrder()
            {
                Id = Convert.ToInt32(prDataRow["Id"]),
                item = Convert.ToString(prDataRow["item"]),
                cost = Convert.ToDecimal(prDataRow["cost"]),
                date = Convert.ToString(prDataRow["date"]),
                name = Convert.ToString(prDataRow["name"]),
                email = Convert.ToString(prDataRow["email"]),
            };
        }

        public List<clsCosmetic> getCategoryCosmetics(string Name)
        {
            DataTable lcResult = clsDbConnection.GetDataTable("SELECT * FROM item WHERE category = '" + Name + "'", null);
            List<clsCosmetic> lcWorks = new List<clsCosmetic>();
            foreach (DataRow dr in lcResult.Rows)
                lcWorks.Add(dataRow2clsCosmetic(dr));
            return lcWorks;

        }

        private clsCosmetic dataRow2clsCosmetic(DataRow prDataRow)
        {
            return new clsCosmetic()
            {
                Name = Convert.ToString(prDataRow["name"]),
                Price = Convert.ToDecimal(prDataRow["price"]),
                Stock = Convert.ToInt16(prDataRow["stock"]),
                Category = Convert.ToString(prDataRow["category"]),
                Skintype = Convert.ToString(prDataRow["skintype"]),
                Cover = prDataRow["cover"] is DBNull ? (string)null : Convert.ToString(prDataRow["cover"]),
                moisturizer = prDataRow["moisturizer"] is DBNull ? (string)null : Convert.ToString(prDataRow["moisturizer"]),
                OilyControl = prDataRow["oil-control"] is DBNull ? (string)null : Convert.ToString(prDataRow["oil-control"]),
                Oxidizability = prDataRow["oxidizability"] is DBNull ? (string)null : Convert.ToString(prDataRow["oxidizability"])
            };
        }

        public string DeleteCosmetic(string Name)
        {   // delete
            try
            {
                Dictionary<string, object> par = new Dictionary<string, object>(2);
                par.Add("Name", Name);
                int lcRecCount = clsDbConnection.Execute(
               "DELETE FROM item WHERE name = @Name", par);
                if (lcRecCount == 1)
                    return "One cosmetic deleted";
                else
                    return "Unexpected cosmetic delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }

        }

        public string PutCosmetic(clsCosmetic prCosmetic)
        {   // update
            try
            {
                int lcRecCount = clsDbConnection.Execute(
               "UPDATE item SET price=@Price, stock=@Stock, cover=@Cover, moisturizer=@moisturizer, [oil-control]=@Oilycontrol, oxidizability=@Oxidizability WHERE name = @Name",
               prepareCosmeticParameters(prCosmetic));
                if (lcRecCount == 1)
                    return "One Cosmetic updated";
                else
                    return "Unexpected Cosmetic update count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }

        }

        public string PostCosmetic(clsCosmetic prCosmetic)
        {//insert
            try
            {
                int lcRecCount = clsDbConnection.Execute("INSERT INTO item " +
                "(name, price, stock, category, skintype, cover, moisturizer, [oil-control], oxidizability) " +
                "VALUES (@Name, @Price, @Stock, @Category, @Skintype, @Cover, @moisturizer, @OilyControl, @Oxidizability)",
                prepareCosmeticParameters(prCosmetic));
                if (lcRecCount == 1)
                    return "One Cosmetic inserted";
                else
                    return "Unexpected Cosmetic insert count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        private Dictionary<string, object> prepareCosmeticParameters(clsCosmetic prCosmetic)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(10);
            par.Add("Name", prCosmetic.Name);
            par.Add("Category", prCosmetic.Category);
            par.Add("Cover", prCosmetic.Cover);
            par.Add("moisturizer", prCosmetic.moisturizer);
            par.Add("OilyControl", prCosmetic.OilyControl);
            par.Add("Oxidizability", prCosmetic.Oxidizability);
            par.Add("Price", prCosmetic.Price);
            par.Add("Skintype", prCosmetic.Skintype);
            par.Add("Stock", prCosmetic.Stock);
            return par;
        }

        public string DeleteOrder(string Id)
        {   // delete
            try
            {
                Dictionary<string, object> par = new Dictionary<string, object>(2);
                par.Add("Id", Id);
                int lcRecCount = clsDbConnection.Execute(
               "DELETE FROM orders WHERE Id = @Id", par);
                if (lcRecCount == 1)
                    return "One order deleted";
                else
                    return "Unexpected order delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }
    }
}

