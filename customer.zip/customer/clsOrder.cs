﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace customer
{
    public class clsOrder
    {
        public int Id { get; set; }
        public string item { get; set; }
        public decimal cost { get; set; }
        public string date { get; set; }
        public string name { get; set; }
        public string email { get; set; }

        public override string ToString()
        {
            return item + "\t" + date;
        }

    }
}
