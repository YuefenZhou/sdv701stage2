﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;



// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace customer
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BlankPage1 : Page
    {
        private clsCategory _Category;
        public clsCosmetic _Cosmetic = new clsCosmetic();
        private static Dictionary<String, BlankPage1> _CosmeticsFormList = new Dictionary<String, BlankPage1>();

        public BlankPage1()
        {
            this.InitializeComponent();
        }


        public static void Run(clsCategory prCategory)
        {
            BlankPage1 lcCosmeticForm;
            if (string.IsNullOrEmpty(prCategory.Name) ||
            !_CosmeticsFormList.TryGetValue(prCategory.Name, out lcCosmeticForm))
            {
                lcCosmeticForm = new BlankPage1();
                _CosmeticsFormList.Add(prCategory.Name, lcCosmeticForm);
                lcCosmeticForm.SetDetails(prCategory);
            }
            else
            {
                lcCosmeticForm.UpdateDisplay();
            }
        }
        private async void UpdateDisplay()
        {

            lstCosmetic.DataContext = null;
            lstCosmetic.DataContext = await ServiceClient.GetCategoryCosmeticsAsync(_Cosmetic.Name);
        }
        public void SetDetails(clsCategory prCategory)
        {
            _Category = prCategory;
            txbCosmetic.Text = "Category: " + _Category.Name;
            UpdateDisplay();
        }

        private void TxbItemInformation_SelectionChanged(object sender, RoutedEventArgs e)
        {
        }
        protected /*async*/ override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            try
            {
                if (e.Parameter != null)
                {
                    string lcCategoryName = e.Parameter.ToString();
                   //_Cosmetic = await MainPage.SvcClient.GetCategoryCosmeticsAsync(lcCategoryName);
                    UpdateDisplay();
                }
            }
            catch(Exception ex)
            {
                txbMessage.Text = ex.Message;
            }

        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Frame.GoBack();
        }

        private void LstCosmetic_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            try
            {
                UpdateDisplay();
            }
            catch (Exception ex)
            {
                txbMessage.Text = ex.Message;
            }
        }

        private /*async*/ void LstCosmetic_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                //lstCosmetic.ItemsSource = await ServiceClient.GetCategoryCosmeticsAsync(lstCategory.SelectedItem);
            }
            catch (Exception ex)
            {
                txbMessage.Text = ex.Message;
            }
        }
    }
}
