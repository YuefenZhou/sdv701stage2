﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
//name:winona
//data:2019/6/21
//description:mainpage,to show the category

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace customer
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                lstCategory.ItemsSource = await ServiceClient.GetCategoryNamesAsync();
            }
            catch (Exception ex)
            {
                txbMessage.Text = ex.Message;
            }
        }

        private void BtnViewCosmetics_Click(object sender, RoutedEventArgs e)
        {
            clsCategory lcKey;
            lcKey = (clsCategory)lstCategory.SelectedItem;
            if (lcKey.Name!= null)
                try
                {
                    Frame.Navigate(typeof(BlankPage1), lstCategory.SelectedItem);
                }
                catch (Exception ex)
                {
                    txbMessage.Text = ex.Message + "This should never occur";
                }
        }

        private void BtnQuit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Exit();
        }

        private void TxbMessage_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }
    }
}
